noiselevel=[10,20,30,40,50,60,70,80];
load('coil20.mat')
image1=X(:,:,649);
for i=1:length(noiselevel)
    w=255*ones(32,1);
    w=uint8(w);
    l=noiselevel(i);
    filename=['coil20_select1noise',int2str(l),'.mat']
    load(filename)
    temp=NX(:,:,649);
    image1=[image1,w,temp];
end
noiselevel=[10,20,30,40,50,60,70,80];
load('coil20.mat')
image2=X(:,:,973);
for i=1:length(noiselevel)
    l=noiselevel(i);
    filename=['coil20_select1noise',int2str(l),'.mat']
    load(filename)
    temp=NX(:,:,973);
    image2=[image2,temp];
end
noiselevel=[10,20,30,40,50,60,70,80];
load('coil20.mat')
image3=X(:,:,1153);
for i=1:length(noiselevel)
    l=noiselevel(i);
    filename=['coil20_select1noise',int2str(l),'.mat']
    load(filename)
    temp=NX(:,:,1153);
    image3=[image3,temp];
end
%image=[image1;image2;image3];
imshow(image1)