function initialClusters=makeInitialClusters(y)
num=length(unique(y));
initialClusters={};
for i=1:num
    initialClusters{i}=[find(y==i)];
end