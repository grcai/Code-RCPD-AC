function [a,b1,b2] = Data_Normalized_h1(a)
[m,n]= size(a);
b1=[];
b2=[];
for i = 1: n
    amax = max(a(:,i));  
    amin = min(a(:,i));  
    for j = 1: m
       a(j,i)= (a(j,i)-amin)/(amax-amin);  
    end
    b1=[b1,amin];
    b2=[b2,amax-amin];
end
a(find(isnan(a)==1)) = 0;

